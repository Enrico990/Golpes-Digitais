function openGroup(group) {
  document.querySelectorAll('.chat-group').forEach(chat => {
      chat.classList.remove('active');
  });
  document.getElementById(`chat-${group}`).classList.add('active');
}

function sendMessage(group) {
  const input = document.getElementById(`input-${group}`);
  const message = input.value.trim();
  if (message) {
      const messagesContainer = document.getElementById(`messages-${group}`);
      const newMessage = document.createElement('div');
      newMessage.classList.add('message');
      newMessage.textContent = message;
      messagesContainer.appendChild(newMessage);
      input.value = '';
      messagesContainer.scrollTop = messagesContainer.scrollHeight;
  }
}

openGroup('Golpes por Email');